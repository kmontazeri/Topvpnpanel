<?php
// Configuration file
?>